package com.barslogin.server.brixter.kim.d.duenas.Controller;

import java.util.List;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.barslogin.server.brixter.kim.d.duenas.DAO.User;
import com.barslogin.server.brixter.kim.d.duenas.entity.UserRepositort;
@RestController
@RequestMapping("/")
public class UserController {
	
	private UserRepositort userRepository;
	
	
	public UserController(UserRepositort userRepository) {
		
		this.userRepository = userRepository;
	}


	@GetMapping("/{username}/{password}")
	public List<User> getUserByNameAndPass(@PathVariable("username") final String userName, @PathVariable("password") final String password){
		
//		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//		
//		List<User> findName = userRepository.findByUserNameAndPassword(userName, password);
//		findName.get(0).setPassword(passwordEncoder.encode(findName.get(0).getPassword()));
		
		return userRepository.findByUserNameAndPassword(userName, password);
		
	}
	
	
}
