package com.barslogin.server.brixter.kim.d.duenas.entity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.barslogin.server.brixter.kim.d.duenas.DAO.User;

public interface UserRepositort extends JpaRepository<User, Integer>{

	List<User> findByUserNameAndPassword(String userName, String password);
	User findByUserName(String userName);
}
