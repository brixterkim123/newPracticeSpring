package com.accenture.bars.controller;

import java.io.File;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.bars.circuitbreaker.CRUDCircuitBreaker;
import com.accenture.bars.domain.Account;
import com.accenture.bars.domain.Billing;
import com.accenture.bars.domain.Customer;
import com.accenture.circuitbreaker.BarsHystrix;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;

/**
 * BarsController Class
 *
 * @author christian.p.c.mirano
 * @since 17.10.18
 */

/**
 * BarsController - controller of the Bars Web App
 *
 */
@EnableCircuitBreaker
@Controller
public class BarsController {
	protected static final Logger logger = LoggerFactory.getLogger(BarsController.class);

	@Autowired
	BarsHystrix barsHystrix;

	@Autowired
	CRUDCircuitBreaker crudcb;

	String role;

	@RequestMapping(value = "/bars")
	public String roleFromAccount(@RequestParam(value = "rights", required = true) String role, Model model) {

		String page = "";
		if ("admin".equals(role)) {
			page = "barsadmin";
		} else if ("user".equals(role)) {
			page = "barsnonadmin";
		}
		this.role = role;
		model.addAttribute("rights", role);
		return page;
	}

	@RequestMapping(value = "/")
	public String goToBarsHome() {
		String page = "";
		if ("admin".equals(role)) {
			page = "barsadmin";
		} else if ("user".equals(role)) {
			page = "barsnonadmin";
		}
		return page;
	}

	@RequestMapping(value = "/process")
	public ModelAndView processRequest(@RequestParam("files") File file) throws JSONException {

		return barsHystrix.execute(file, role);
	}

	@RequestMapping(value = "/showCustomer")
	public String showCustomer() {
		String page = "showCustomer";
		return page;
	}

	@RequestMapping(value = "/showBilling")
	public String showBilling() {

		return "showBilling";
	}

	@RequestMapping(value = "/showBillingInActive")
	public String showBillingInActive() {

		return "showBillingInActive";
	}

	@RequestMapping(value = "/showAccounts")
	public String showAccounts() {

		return "showAccounts";
	}

	@RequestMapping(value = "/deleteCustomer")
	public ModelAndView deleteCustomer(@RequestParam("customerId") int customerId) throws JSONException {
		ModelAndView mv = crudcb.deleteCustomer(customerId);
		return mv;
	}

	@RequestMapping(value = "/deleteBilling")
	public ModelAndView goToDeleteBilling(@RequestParam("billingId") int billingId) throws JSONException {
		ModelAndView mv = crudcb.deleteAccount(billingId);
		return mv;
	}

	@RequestMapping(value = "/deleteAccount")
	public ModelAndView goToDeleteAccount(@RequestParam("accountId") int accountId) throws JSONException {
		ModelAndView mv = crudcb.deleteAccount(accountId);
		return mv;
	}

	////////////////////////////// UPDATE
	////////////////////////////// ACCOUNT////////////////////////////////////////////////////////
	@RequestMapping(value = "/updateBarsAccount")
	public ModelAndView updatePage(@RequestParam("accountId") int accountId) throws JSONException {
		ModelAndView model = new ModelAndView();
		try {
			if (role.equals("admin")) {
				String url = "http://localhost:2000/bars/getAccount/" + accountId;
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);

				Account account = new Account(cr.getEntity(String.class));
				account.addModelAndView(model);
				model.setViewName("updatebarsaccount");
			} else {
				model.addObject("ERROR", "Login session for admin is not available please relog ...");
				model.setViewName("showAccounts");

				return model;
			}
		} catch (Exception e) {

			model.addObject("ERROR", "Login session for admin is not available please relog ...");
			model.setViewName("showAccounts");

			return model;
		}

		return model;
	}

	@RequestMapping(value = "/updateAccount")
	public ModelAndView updateAccount(@RequestParam("accountId") int accountId,
			@RequestParam("accountName") String accountName, @RequestParam("isActive") String isValid,
			@RequestParam("lastEdited") String lastEdited)
			throws UniformInterfaceException, ClientHandlerException, JSONException {
		ModelAndView model = new ModelAndView();
		Account account = new Account(accountId, accountName, isValid, lastEdited);

		String url = "http://localhost:2000/bars/updateAccount";
		Client client = new Client();
		WebResource wr = client.resource(url);
		ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).put(ClientResponse.class, account.toJson());
		cr.getEntity(String.class);

		model.setViewName("showAccounts");

		return model;
	}
	////////////////////////////// UPDATE
	////////////////////////////// ACCOUNT////////////////////////////////////////////////////////

	////////////////////////////// UPDATE
	////////////////////////////// CUSTOMER////////////////////////////////////////////////////////
	@RequestMapping(value = "/updateBarsCustomer")
	public ModelAndView updateCustomer(@RequestParam("customerId") int customerId) throws JSONException {
		ModelAndView model = new ModelAndView();
		try {

			if (role.equals("admin")) {
				String url = "http://localhost:2000/bars/getCustomer/" + customerId;
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);

				Customer customer = new Customer(cr.getEntity(String.class));
				logger.info(customer.getCustomerId() + " CUSTOMER IDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
				customer.addModelAndView(model);
				model.setViewName("updatebarsCustomer");
			} else {
				model.addObject("ERROR", "Login session for admin is not available please relog ...");
				model.setViewName("showCustomer");

				return model;
			}
		} catch (Exception e) {
			model.addObject("ERROR", "Login session for admin is not available please relog ...");
			model.setViewName("showCustomer");
		}
		return model;
	}

	@RequestMapping(value = "/updateCustomer")
	public ModelAndView updateCustomer(@RequestParam("customerId") int customerId,
			@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("address") String address, @RequestParam("status") String status,
			@RequestParam("lastEdited") String lastEdited)
			throws UniformInterfaceException, ClientHandlerException, JSONException {
		ModelAndView model = new ModelAndView();

		Customer customer = new Customer(customerId, firstName, lastName, address, status, lastEdited);

		String url = "http://localhost:2000/bars/updateCustomer";
		Client client = new Client();
		WebResource wr = client.resource(url);
		ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).put(ClientResponse.class, customer.toJson());
		cr.getEntity(String.class);

		model.setViewName("showCustomer");

		return model;
	}

	////////////////////////////// UPDATE
	////////////////////////////// CUSTOMER////////////////////////////////////////////////////////

//////////////////////////////UPDATE BILLING////////////////////////////////////////////////////////
	@RequestMapping(value = "/updateBarsBilling")
	public ModelAndView updateBilling(@RequestParam("billingId") int billingId)
			throws JSONException, ClientHandlerException, UniformInterfaceException, ParseException {

		ModelAndView model = new ModelAndView();
		try {
			if (role.equals("admin")) {
				String url = "http://localhost:2000/bars/getBilling/" + billingId;
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);

				Billing billing = new Billing(cr.getEntity(String.class));
				billing.addModelAndView(model);
				model.setViewName("updatebarsBilling");
			} else {
				model.addObject("ERROR", "Login session for admin is not available please relog ...");
				model.setViewName("showBilling");

				return model;
			}
		} catch (Exception e) {
			model.addObject("ERROR", "Login session for admin is not available please relog ...");
			model.setViewName("showBilling");
			return model;
		}

		return model;
	}

	@RequestMapping(value = "/updateBilling")
	public ModelAndView updateBilling(@RequestParam("billingId") int billingId,
			@RequestParam("billingCycle") int billingCycle, @RequestParam("billingMonth") String billingMonth,
			@RequestParam("amount") String amount, @RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate, @RequestParam("lastEdited") String lastEdited)
			throws UniformInterfaceException, ClientHandlerException, JSONException, ParseException {
		ModelAndView model = new ModelAndView();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateStart = sdf.parse(startDate);
		Date dateEnd = sdf.parse(endDate);

		if (billingCycle < 1 || billingCycle >= 13) {
			model.addObject("ERROR", "INVALID BILLING CYCLE ID. MUST BE GREATER THAN 0 AND LESS THAN 13");
			model.setViewName("showBilling");
		} else {

			if (dateStart.compareTo(dateEnd) > 0) {
				model.addObject("ERROR", "INVALID DATE. START DATE CANNOT BE GREATER THAN END DATE");
				model.setViewName("showBilling");
			} else if (dateStart.compareTo(dateEnd) < 0) {

				
				Billing billing = new Billing(billingId, billingCycle, billingMonth, Double.parseDouble(amount),
						startDate, endDate, lastEdited);
				String url = "http://localhost:2000/bars/updateBilling";
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).put(ClientResponse.class, billing.toJson());
				cr.getEntity(String.class);

				model.setViewName("showBilling");

			} else if (dateStart.compareTo(dateEnd) == 0) {
				model.addObject("ERROR", "INVALID DATE. START DATE CANNOT BE EQUAL THAN END DATE");
				model.setViewName("showBilling");
			}

		}

		return model;
	}

//////////////////////////////UPDATE BILLING////////////////////////////////////////////////////////

	@RequestMapping(value = "/listOfInactive")
	public String listOfInactive() {

		return "listOfInactive";
	}

	@RequestMapping(value = "/showInactiveAccount")
	public String showInactiveAccount() {

		return "showInactiveAccount";
	}

}