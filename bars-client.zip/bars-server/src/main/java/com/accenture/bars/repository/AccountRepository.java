package com.accenture.bars.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accenture.bars.domain.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {

	Account findByAccountId(int accountId);
}
