package com.accenture.bars.factory;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.bars.file.CSVInputFileImpl;
import com.accenture.bars.file.IInputFile;
import com.accenture.bars.file.TextInputFileImpl;

/**
 * InputFileFactory - class responsible for the creation of TextInputFileImpl
 * class and CSVInputFileImpl
 *
 */
public class InputFileFactory {
	protected static final Logger logger = LoggerFactory.getLogger(InputFileFactory.class);

	private static InputFileFactory instance;

	private InputFileFactory() {

	}

	public static InputFileFactory getInstance() {
		if (instance == null) {
			instance = new InputFileFactory();
		}

		return instance;
	}

	public IInputFile getInputFile(File file) {
		IInputFile inputFile = null;
		String[] files = file.toString().split("\\.");
		String extension = files[files.length - 1];
		logger.info(extension+" FILE NAMEEE EXTENSION");
		if ("txt".equals(extension)) {
			logger.info(extension+" INSIDE TXT");
			inputFile = new TextInputFileImpl();
			inputFile.setFile(file);
			return inputFile;
		} else if ("csv".equals(extension)) {
			inputFile = new CSVInputFileImpl();
			inputFile.setFile(file);
			return inputFile;
		}

		return inputFile;
	}

}
