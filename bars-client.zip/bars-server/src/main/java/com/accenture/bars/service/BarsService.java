package com.accenture.bars.service;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.bars.domain.Account;
import com.accenture.bars.domain.Billing;
import com.accenture.bars.domain.Customer;
import com.accenture.bars.domain.Record;
import com.accenture.bars.domain.Request;
import com.accenture.bars.exception.BarsException;
import com.accenture.bars.factory.InputFileFactory;
import com.accenture.bars.file.IInputFile;
import com.accenture.bars.file.IOutputFile;
import com.accenture.bars.file.XMLOutputFileImpl;
import com.accenture.bars.repository.AccountRepository;
import com.accenture.bars.repository.BillingRepository;
import com.accenture.bars.repository.CustomerRepository;
import com.accenture.bars.repository.RequestRepository;

@Path("/bars")
public class BarsService {

	protected static final Logger logger = LoggerFactory.getLogger(BarsService.class);
	private static Logger log = LoggerFactory.getLogger(BarsService.class);

	@Autowired
	RequestRepository requestRepository;

	@Autowired
	BillingRepository billingRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	AccountRepository accountRepository;

	IInputFile inputFile;
	IOutputFile outputFile;

	// http://localhost:1998/bars/execute?file=FILE
	@GET
	@Path("/execute")
	@Produces(MediaType.APPLICATION_JSON)
	public Response execute(@QueryParam("file") String file) throws JSONException {
		log.info("Access /execute");

		JSONObject json = new JSONObject();

		inputFile = InputFileFactory.getInstance().getInputFile(new File(file));

		if ("".equals(file)) {
			json.put("ERROR", BarsException.PATH_DOES_NOT_EXIST);
			return Response.status(405).type(MediaType.APPLICATION_JSON).entity(json.toString()).build();
		} else if (null == inputFile) {
			json.put("ERROR", BarsException.NO_SUPPORT_FILE);
			return Response.status(405).type(MediaType.APPLICATION_JSON).entity(json.toString()).build();
		}

		inputFile.setFile(new File(file));

		try {
			List<Request> requests = inputFile.readFile();
			if (requests.isEmpty()) {
				json.put("ERROR", BarsException.NO_RECORDS_TO_READ);
				return Response.status(405).type(MediaType.APPLICATION_JSON).entity(json.toString()).build();
			}

			for (Request request : requests) {
				requestRepository.save(request);
			}

			List<Record> records = fileProcessorRetrieveRecords();

			if (records.isEmpty()) {
				json.put("ERROR", BarsException.NO_RECORDS_TO_WRITE);
				return Response.status(405).type(MediaType.APPLICATION_JSON).entity(json.toString()).build();
			}

			writeOutput(records);

			return Response.status(200).build();

		} catch (BarsException e) {
			json.put("ERROR", e.getMessage());
			return Response.status(405).type(MediaType.APPLICATION_JSON).entity(json.toString()).build();
		}

	}

	// http://localhost:1998/bars/getrecords
	@GET
	@Path("/getrecords")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Record> getRecords() {
		log.info("Access /getrecords");
		List<Record> records = fileProcessorRetrieveRecords();
		requestRepository.deleteAll();
		return records;
	}

	public List<Record> fileProcessorRetrieveRecords() {
		log.info("Access /fileProcessorRetrieveRecords");
		List<Object[]> objectRecords = requestRepository.findRecords();
		List<Record> records = new ArrayList<>();
		for (Object[] object : objectRecords) {
			records.add(new Record((int) object[0], (java.sql.Date) object[1], (java.sql.Date) object[2],
					(String) object[3], (String) object[4], (double) object[5]));
		}
		return records;
	}

	public void writeOutput(List<Record> records) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");
		String date = dateFormat.format(new Date());

		outputFile = new XMLOutputFileImpl();
		outputFile.setFile(new File("C:/BARS/Report/BARS_Report-" + date + ".xml"));
		outputFile.writeFile(records);
	}

	///////////////////////////// SHOWWW
	///////////////////////////// ///////////////////////////////////////////////

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/showCustomer")
	public List<Customer> getCustomer() {

		List<Customer> customer = customerRepository.findAll();
		List<Customer> customerActive = new ArrayList<>();
		for (int i = 0; i < customer.size(); i++) {

			if (customer.get(i).getStatus().equalsIgnoreCase("Y")) {
				customerActive.add(customer.get(i));
			}
		}
		return customerActive;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/showAccount")
	public List<Account> getAccount() {

		List<Account> account = accountRepository.findAll();
		List<Account> accountActive = new ArrayList<>();
		for (int i = 0; i < account.size(); i++) {

			if (account.get(i).getIsActive().equals("Y")) {
				accountActive.add(account.get(i));
			}
		}
		return accountActive;
	}

	////////////////////////////// jSON GET ACCOUNT /////////////////////
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getAccount/{accountId}")
	public Response getAccount(@PathParam("accountId") int accountId) throws JSONException {
		Account account = accountRepository.findByAccountId(accountId);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("accountId", account.getAccountId());
		jsonObject.put("accountName", account.getAccountName());
		jsonObject.put("dateCreated", account.getDateCreated());
		jsonObject.put("isActive", account.getIsActive());
		jsonObject.put("lastEdited", account.getLastEdited());

		return Response.status(200).entity(jsonObject.toString()).type(MediaType.APPLICATION_JSON).build();

	}

	////////////////////////////// jSON GET ACCOUNT /////////////////////

	////////////////////////////// jSON GET CUSTOMER /////////////////////
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getCustomer/{customerId}")
	public Response getCustomer(@PathParam("customerId") int customerId) throws JSONException {
		Customer customer = customerRepository.findByCustomerId(customerId);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("customerId", customer.getCustomerId());
		jsonObject.put("firstName", customer.getFirstName());
		jsonObject.put("lastName", customer.getLastName());
		jsonObject.put("address", customer.getAddress());
		jsonObject.put("dateCreated", customer.getDateCreated());
		jsonObject.put("status", customer.getStatus());
		jsonObject.put("lastEdited", customer.getLastEdited());

		return Response.status(200).entity(jsonObject.toString()).type(MediaType.APPLICATION_JSON).build();

	}

	////////////////////////////// jSON GET CUSTOMER /////////////////////

	////////////////////////////// jSON GET BILLING /////////////////////

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getBilling/{billingId}")
	public Response getBilling(@PathParam("billingId") int billingId) throws JSONException {
		Billing billing = billingRepository.findByBillingId(billingId);
		JSONObject jsonObject = new JSONObject();
		logger.info(billing.getBillingId() + " BILIIIIIIIIIIIIIIIIIIIIIIIING IDDDDDDDDDDDDDDDD");
		System.out.println(billing.getBillingId() + " BILINGGGGGGGGGGGGGGGGGGGGGGGID");
		jsonObject.put("billingId", billing.getBillingId());
		jsonObject.put("billingCycle", billing.getBillingCycle());
		jsonObject.put("billingMonth", billing.getBillingMonth());
		jsonObject.put("amount", billing.getAmount());
		jsonObject.put("startDate", billing.getStartDate());
		jsonObject.put("endDate", billing.getEndDate());
		jsonObject.put("lastEdited", billing.getLastEdited());

		return Response.status(200).entity(jsonObject.toString()).type(MediaType.APPLICATION_JSON).build();

	}

	////////////////////////////// jSON GET BILLING /////////////////////

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/showInactiveAccount")
	public List<Account> showInactiveAccount() {

		List<Account> account = accountRepository.findAll();
		List<Account> accountActive = new ArrayList<>();
		for (int i = 0; i < account.size(); i++) {

			if (account.get(i).getIsActive().equals("N")) {
				accountActive.add(account.get(i));
			}
		}
		return accountActive;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/showBilling")
	public List<Billing> getAccounts() {

		log.info("Access /listallrecords");
		List<Account> account = accountRepository.findAll();
		List<Billing> billing = billingRepository.findAll();
		List<Billing> isActive = new ArrayList<>();

		for (int i = 0; i < billing.size(); i++) {
			for (int j = 0; j < account.size(); j++) {

				if (billing.get(i).getAccount().getAccountId() == account.get(j).getAccountId()) {
					String status = account.get(j).getIsActive();
					if (status.equalsIgnoreCase("Y")) {
						isActive.add(billing.get(i));
					}

				}
			}
		}
		return isActive;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/showBillingInActive")
	public List<Billing> showBillingInActive() {

		log.info("Access /listallrecords");
		List<Account> account = accountRepository.findAll();
		List<Billing> billing = billingRepository.findAll();
		List<Billing> isActive = new ArrayList<>();

		for (int i = 0; i < billing.size(); i++) {
			for (int j = 0; j < account.size(); j++) {

				if (billing.get(i).getAccount().getAccountId() == account.get(j).getAccountId()) {
					String status = account.get(j).getIsActive();
					if (status.equalsIgnoreCase("N")) {
						isActive.add(billing.get(i));
					}

				}
			}
		}
		return isActive;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listOfInactive")
	public List<Customer> listOfInactive() {

		List<Customer> customer = customerRepository.findAll();
		List<Customer> customerActive = new ArrayList<>();
		for (int i = 0; i < customer.size(); i++) {

			if (customer.get(i).getStatus().equals("N")) {
				customerActive.add(customer.get(i));
			}
		}
		return customerActive;
	}

	@DELETE
	@Path("/deleteCustomer/{customerId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteCustomer(@PathParam("customerId") int customerId) throws JSONException {

		customerRepository.delete(customerRepository.findByCustomerId(customerId));
		JSONObject response = new JSONObject();
		response.put("INFO", "Successfully Deleted Customer");

		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(response.toString()).build();
	}

	@DELETE
	@Path("/deleteBilling/{billingId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteBilling(@PathParam("billingId") int billingId) throws JSONException {

		billingRepository.delete(billingRepository.findByBillingId(billingId));
		JSONObject response = new JSONObject();
		response.put("INFO", "Successfully Deleted Customer");

		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(response.toString()).build();
	}

	@DELETE
	@Path("/deleteAccount/{accountId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteAccount(@PathParam("accountId") int accountId) throws JSONException {

		accountRepository.delete(accountRepository.findByAccountId(accountId));
		JSONObject response = new JSONObject();
		response.put("INFO", "Successfully Deleted Customer");

		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(response.toString()).build();
	}

	@PUT
	@Path("/updateAccount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateAccount(Account account) throws JSONException {
		JSONObject response = new JSONObject();
		Account tempAcct = accountRepository.findByAccountId(account.getAccountId());
		System.out.println(tempAcct.getAccountId() + "   " + tempAcct.getDateCreated());
		account.setDateCreated(tempAcct.getDateCreated());
		account.setCustomer(tempAcct.getCustomer());
		accountRepository.save(account);
		response.put("INFO", "Successfully Updated Account!");
		return Response.status(200).entity(response.toString()).type(MediaType.APPLICATION_JSON).build();

	}

///////////////////////////// UPDATE CUSTOMER /////////////////////////////////////////////////////////////////////////	
	@PUT
	@Path("/updateCustomer")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateCustomer(Customer customer) throws JSONException {
		JSONObject response = new JSONObject();

		Customer tempCustomer = customerRepository.findByCustomerId(customer.getCustomerId());

		customer.setDateCreated(tempCustomer.getDateCreated());
		customer.setAccounts(tempCustomer.getAccounts());
		System.out.println("INITIAL");
		customerRepository.save(customer);
		response.put("INFO", "Successfully Updated Customer!");
		return Response.status(200).entity(response.toString()).type(MediaType.APPLICATION_JSON).build();

	}
///////////////////////////// UPDATE UCSTOMER /////////////////////////////////////////////////////////////////////////	

///////////////////////////// UPDATE Billling /////////////////////////////////////////////////////////////////////////	
	@PUT
	@Path("/updateBilling")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateBilling(Billing billing) throws JSONException, ParseException {
		JSONObject response = new JSONObject();

		Billing tempBilling = billingRepository.findByBillingId(billing.getBillingId());

		int billingCycle = billing.getBillingCycle();
		
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        Date date1 = sdf.parse("2009-12-31");
	        Date date2 = sdf.parse("2010-01-31");

	        System.out.println("date1 : " + sdf.format(date1));
	        System.out.println("date2 : " + sdf.format(date2));

	        if (date1.compareTo(date2) > 0) {
	            System.out.println("Date1 is after Date2");
	        } else if (date1.compareTo(date2) < 0) {
	            System.out.println("Date1 is before Date2");
	        } else if (date1.compareTo(date2) == 0) {
	            System.out.println("Date1 is equal to Date2");
	        } else {
	            System.out.println("How to get here?");
	        }

		
		if(billingCycle == 1) {
			billing.setBillingMonth("January");
		}else if(billingCycle == 2) {
			billing.setBillingMonth("February");
		}else if(billingCycle == 3) {
			billing.setBillingMonth("March");
		}else if(billingCycle == 4) {
			billing.setBillingMonth("April");
		}else if(billingCycle == 5) {
			billing.setBillingMonth("May");
		}else if(billingCycle == 6) {
			billing.setBillingMonth("June");
		}else if(billingCycle == 7) {
			billing.setBillingMonth("July");
		}else if(billingCycle == 8) {
			billing.setBillingMonth("August");
		}else if(billingCycle == 9) {
			billing.setBillingMonth("Semptember");
		}else if(billingCycle == 10) {
			billing.setBillingMonth("October");
		}else if(billingCycle == 11) {
			billing.setBillingMonth("November");
		}else if(billingCycle == 12) {
			billing.setBillingMonth("December");
		}else {

			response.put("ERROR", "Invalid BillingCycle!");
			return Response.status(500).entity(response.toString()).type(MediaType.APPLICATION_JSON).build();

		}
		
		billing.setStartDate(tempBilling.getStartDate());
		billing.setEndDate(tempBilling.getEndDate());
		billing.setAccount(tempBilling.getAccount());
		
		System.out.println("INITIAL");

		billingRepository.save(billing);
		response.put("INFO", "Successfully Updated Customer!");
		return Response.status(200).entity(response.toString()).type(MediaType.APPLICATION_JSON).build();

	}
///////////////////////////// UPDATE Billling /////////////////////////////////////////////////////////////////////////	

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/updateAccount/{account}")
	public String updateAccount(@PathParam("account") String account) {

		return "success";

	}
}
