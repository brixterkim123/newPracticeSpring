package bars.login.client.brixter.kim.d.duenas.entity;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import bars.login.client.brixter.kim.d.duenas.ClientProxy;
import bars.login.server.brixter.kim.d.duenas.DAO.User;

@Controller
@RequestMapping("/")
public class ClientController {
	
	@Autowired
	private ClientProxy clientProxy;
	
	@RequestMapping("/login")
	public String index() {
		return "login";
	}
	
	@GetMapping("/all")
	public List<User> allUser(){
		
		return clientProxy.getAll();
	}
	
	@PostMapping("/loginMember")
	public ModelAndView getUserPassword(HttpServletRequest request) {
		
		ModelAndView model = new ModelAndView();
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		if(clientProxy.getUserByNameAndPass(userName, password).size() > 0) {
			model.addObject("userName", userName);
			model.setViewName("success");
			return model;
		}else {
			model.setViewName("fail");
			return model;
		}
		
		
		
		
	}
}
